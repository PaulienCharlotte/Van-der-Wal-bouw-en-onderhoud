
import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate submission
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="bg-white">
      {/* Page Header */}
      <section className="bg-gray-50 py-20 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Contact</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Vragen of direct een afspraak inplannen? Ik sta voor u klaar om alle mogelijkheden te bespreken.
          </p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
            
            {/* Contact Info Sidebar */}
            <div className="lg:col-span-1 space-y-12">
              <div>
                <h3 className="text-2xl font-bold mb-6 border-b-2 border-[#b88e4b] pb-2 inline-block">Direct Contact</h3>
                <div className="space-y-6 mt-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gray-50 rounded-lg flex items-center justify-center text-[#b88e4b]">
                      <i className="fas fa-phone-alt text-xl"></i>
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Telefoon</p>
                      <p className="text-lg font-bold text-gray-900">+31 (0)6 1234 5678</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gray-50 rounded-lg flex items-center justify-center text-[#b88e4b]">
                      <i className="fas fa-envelope text-xl"></i>
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Email</p>
                      <p className="text-lg font-bold text-gray-900">info@vakwerkbouw.nl</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-6 border-b-2 border-[#b88e4b] pb-2 inline-block">Mijn Werkplaats</h3>
                <div className="space-y-6 mt-4">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gray-50 rounded-lg flex items-center justify-center text-[#b88e4b]">
                      <i className="fas fa-map-marker-alt text-xl"></i>
                    </div>
                    <div>
                      <p className="text-sm font-bold text-gray-400 uppercase tracking-widest">Adres</p>
                      <p className="text-lg font-bold text-gray-900">Bouwstraat 123<br />1234 AB, Amsterdam</p>
                    </div>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-2xl font-bold mb-6 border-b-2 border-[#b88e4b] pb-2 inline-block">Openingstijden</h3>
                <div className="space-y-4 mt-4 text-gray-600">
                  <div className="flex justify-between">
                    <span>Maandag - Vrijdag:</span>
                    <span className="font-bold">08:00 - 18:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Zaterdag:</span>
                    <span className="font-bold">09:00 - 14:00</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Zondag:</span>
                    <span className="font-bold">Gesloten</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2 bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-gray-100">
              <h3 className="text-3xl font-bold mb-8">Stuur een Bericht</h3>
              
              {submitted ? (
                <div className="bg-green-50 border border-green-200 text-green-700 p-6 rounded-xl animate-fadeIn">
                  <div className="flex items-center gap-3 mb-2">
                    <i className="fas fa-check-circle text-xl"></i>
                    <span className="font-bold">Bericht Verzonden!</span>
                  </div>
                  <p>Bedankt voor uw bericht. Ik neem zo spoedig mogelijk contact met u op.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Naam</label>
                      <input 
                        type="text" 
                        required 
                        className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#b88e4b] outline-none transition-all"
                        placeholder="Uw volledige naam"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Email</label>
                      <input 
                        type="email" 
                        required 
                        className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#b88e4b] outline-none transition-all"
                        placeholder="voorbeeld@mail.com"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Telefoonnummer</label>
                      <input 
                        type="tel" 
                        className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#b88e4b] outline-none transition-all"
                        placeholder="+31 6 ..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Onderwerp</label>
                      <input 
                        type="text" 
                        className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#b88e4b] outline-none transition-all"
                        placeholder="Waar gaat het over?"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">Bericht</label>
                    <textarea 
                      required 
                      rows={6} 
                      className="w-full p-4 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-[#b88e4b] outline-none transition-all resize-none"
                      placeholder="Uw vraag of opmerking..."
                    ></textarea>
                  </div>
                  
                  <button 
                    type="submit" 
                    className="w-full md:w-auto bg-[#b88e4b] text-white px-12 py-5 rounded-xl font-bold text-lg hover:bg-[#a07a3d] hover:shadow-lg transition-all"
                  >
                    Verstuur Bericht
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
      
      {/* Map Placeholder */}
      <section className="h-[400px] w-full bg-gray-100 relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <i className="fas fa-map-marked-alt text-[#b88e4b] text-6xl mb-4"></i>
            <p className="text-gray-500 font-bold uppercase tracking-widest">Kaartweergave niet beschikbaar</p>
            <p className="text-gray-400">Amsterdam, Noord-Holland</p>
          </div>
        </div>
        <img 
          src="https://picsum.photos/id/120/1920/400" 
          alt="Map Background" 
          className="w-full h-full object-cover opacity-30 grayscale"
        />
      </section>
    </div>
  );
};

export default Contact;
