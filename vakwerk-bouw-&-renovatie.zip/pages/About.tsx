
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Page Header */}
      <section className="bg-gray-50 py-20 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Over Ons</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Vakmanschap, integriteit en passie voor bouwen. Ontdek het gezicht achter Vakwerk Bouw & Renovatie.
          </p>
        </div>
      </section>

      {/* Content */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-bold mb-4 text-[#b88e4b]">Mijn Verhaal</h2>
                <p className="text-gray-600 leading-relaxed text-lg">
                  Met meer dan 15 jaar ervaring in de bouwsector heb ik in 2018 besloten om als zelfstandige verder te gaan. Mijn drijfveer was simpel: ik wilde projecten opleveren waar ik echt trots op kon zijn, zonder de tijdsdruk van grote projectontwikkelaars.
                </p>
              </div>
              <div>
                <h2 className="text-3xl font-bold mb-4">De Eenmanszaak Kracht</h2>
                <p className="text-gray-600 leading-relaxed text-lg">
                  Het werken met een eenmanszaak biedt unieke voordelen voor u als klant. U communiceert direct met de persoon die het werk uitvoert. Hierdoor gaan er geen details verloren in de communicatie en kan ik maximale kwaliteit garanderen op elk onderdeel van de bouw.
                </p>
              </div>
              <div className="bg-gray-50 p-8 rounded-xl border-l-4 border-[#b88e4b]">
                <p className="italic text-gray-700 text-xl font-serif">
                  "Bouwen is voor mij niet alleen het stapelen van stenen of het zagen van hout; het is het creëren van een thuis waar mensen zich veilig en prettig voelen."
                </p>
                <span className="block mt-4 font-bold text-[#b88e4b]">— Johan, Oprichter</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <img src="https://picsum.photos/id/102/400/600" alt="Tool detail" className="rounded-lg shadow-lg mt-12" />
              <img src="https://picsum.photos/id/103/400/600" alt="Finished project" className="rounded-lg shadow-lg" />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold">Mijn Kernwaarden</h2>
            <div className="w-20 h-1 bg-[#b88e4b] mx-auto mt-4"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <i className="fas fa-gem text-[#b88e4b] text-3xl"></i>
              </div>
              <h3 className="text-2xl font-bold mb-4">Kwaliteit</h3>
              <p className="text-gray-600">Geen 'snelle' oplossingen, maar duurzaam vakwerk dat generaties lang meegaat.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <i className="fas fa-handshake text-[#b88e4b] text-3xl"></i>
              </div>
              <h3 className="text-2xl font-bold mb-4">Transparantie</h3>
              <p className="text-gray-600">Duidelijke offertes zonder verborgen kosten en eerlijk advies over materialen.</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-md">
                <i className="fas fa-clock text-[#b88e4b] text-3xl"></i>
              </div>
              <h3 className="text-2xl font-bold mb-4">Betrouwbaarheid</h3>
              <p className="text-gray-600">Afspraak is afspraak. Ik kom op tijd en lever op de afgesproken datum op.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
