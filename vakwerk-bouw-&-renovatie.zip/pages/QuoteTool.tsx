
import React, { useState, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";

// Initialize AI
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const QuoteTool: React.FC = () => {
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    projectType: '',
    shape: 'Rechthoekig',
    length: '',
    width: '',
    height: '',
    profile: 'Modern',
    material: 'Eiken',
    extraNotes: '',
    email: '',
    name: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const generateAISummary = async () => {
    setLoading(true);
    try {
      const prompt = `Je bent een assistent voor een bouwbedrijf genaamd Vakwerk. De klant heeft de volgende gegevens ingevoerd:
      Project: ${formData.projectType}
      Vorm: ${formData.shape}
      Afmetingen: ${formData.length}x${formData.width}x${formData.height} cm
      Profiel/Stijl: ${formData.profile}
      Materiaal: ${formData.material}
      Opmerkingen: ${formData.extraNotes}
      
      Schrijf een korte, professionele samenvatting (max 3 zinnen) waarin je de klant bedankt en de complexiteit van dit ${formData.projectType} project in ${formData.material} erkent. Eindig met dat een gedetailleerde offerte volgt.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt
      });

      setAiSummary(response.text || "Bedankt voor uw aanvraag. We hebben uw gegevens ontvangen en komen zo snel mogelijk bij u terug met een gedetailleerd voorstel voor uw project.");
    } catch (error) {
      console.error("AI Error:", error);
      setAiSummary("Bedankt voor uw aanvraag. We hebben uw gegevens succesvol ontvangen.");
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => {
    if (step === 3) {
      generateAISummary();
    }
    setStep(prev => prev + 1);
  };

  const prevStep = () => setStep(prev => prev - 1);

  const renderStep = () => {
    switch(step) {
      case 1:
        return (
          <div className="space-y-6 animate-fadeIn">
            <h3 className="text-2xl font-bold mb-6">Wat voor project heeft u in gedachten?</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {['Kast op Maat', 'Veranda', 'Dakkapel', 'Interieurafwerking', 'Anders'].map((type) => (
                <button
                  key={type}
                  onClick={() => setFormData(prev => ({ ...prev, projectType: type }))}
                  className={`p-6 rounded-xl border-2 text-left transition-all ${formData.projectType === type ? 'border-[#b88e4b] bg-[#b88e4b]/5' : 'border-gray-100 hover:border-gray-200'}`}
                >
                  <span className={`font-bold block ${formData.projectType === type ? 'text-[#b88e4b]' : 'text-gray-900'}`}>{type}</span>
                </button>
              ))}
            </div>
            {formData.projectType === 'Anders' && (
              <input 
                type="text" 
                placeholder="Specificeer uw project..." 
                className="w-full p-4 border border-gray-200 rounded-lg mt-4 focus:ring-2 focus:ring-[#b88e4b] outline-none"
                onChange={(e) => setFormData(prev => ({ ...prev, extraNotes: e.target.value }))}
              />
            )}
          </div>
        );
      case 2:
        return (
          <div className="space-y-6 animate-fadeIn">
            <h3 className="text-2xl font-bold mb-6">Afmetingen & Vorm</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Vorm</label>
                <select 
                  name="shape" 
                  value={formData.shape} 
                  onChange={handleChange}
                  className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none"
                >
                  <option>Rechthoekig</option>
                  <option>L-vorm</option>
                  <option>U-vorm</option>
                  <option>Rond/Ovaal</option>
                  <option>Onregelmatig</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Lengte (cm)</label>
                <input 
                  type="number" 
                  name="length" 
                  value={formData.length} 
                  onChange={handleChange} 
                  className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none"
                  placeholder="bijv. 300"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Breedte (cm)</label>
                <input 
                  type="number" 
                  name="width" 
                  value={formData.width} 
                  onChange={handleChange} 
                  className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none"
                  placeholder="bijv. 200"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Hoogte/Diepte (cm)</label>
                <input 
                  type="number" 
                  name="height" 
                  value={formData.height} 
                  onChange={handleChange} 
                  className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none"
                  placeholder="bijv. 100"
                />
              </div>
            </div>
          </div>
        );
      case 3:
        return (
          <div className="space-y-6 animate-fadeIn">
            <h3 className="text-2xl font-bold mb-6">Afwerking & Materiaal</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Stijl / Profiel</label>
                <div className="flex flex-wrap gap-2">
                  {['Modern', 'Klassiek', 'Industrieel', 'Landelijk'].map(s => (
                    <button
                      key={s}
                      onClick={() => setFormData(prev => ({...prev, profile: s}))}
                      className={`px-6 py-3 rounded-full border-2 transition-all ${formData.profile === s ? 'bg-[#b88e4b] border-[#b88e4b] text-white' : 'border-gray-200 text-gray-600'}`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Materiaal Voorkeur</label>
                <select 
                  name="material" 
                  value={formData.material} 
                  onChange={handleChange}
                  className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none"
                >
                  <option>Eikenhout</option>
                  <option>Vurenhout</option>
                  <option>MDF (overschilderbaar)</option>
                  <option>Douglas</option>
                  <option>Kunststof</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">Extra wensen of details</label>
              <textarea 
                name="extraNotes" 
                value={formData.extraNotes} 
                onChange={handleChange}
                className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none h-32"
                placeholder="Beschrijf hier eventuele specifieke wensen..."
              ></textarea>
            </div>
          </div>
        );
      case 4:
        return (
          <div className="space-y-6 animate-fadeIn">
            <h3 className="text-2xl font-bold mb-6">Uw Contactgegevens</h3>
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Volledige Naam</label>
                <input 
                  type="text" 
                  name="name" 
                  value={formData.name} 
                  onChange={handleChange} 
                  className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none"
                  placeholder="Jan de Vries"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">E-mailadres</label>
                <input 
                  type="email" 
                  name="email" 
                  value={formData.email} 
                  onChange={handleChange} 
                  className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#b88e4b] outline-none"
                  placeholder="jan@voorbeeld.nl"
                  required
                />
              </div>
            </div>
            <p className="text-sm text-gray-500 italic text-center py-4">
              Na het verzenden ontvangt u een bevestiging en neem ik binnen 48 uur contact met u op.
            </p>
          </div>
        );
      case 5:
        return (
          <div className="text-center py-12 animate-fadeIn">
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
              <i className="fas fa-check text-4xl"></i>
            </div>
            <h2 className="text-3xl font-bold mb-4">Aanvraag Verzonden!</h2>
            {loading ? (
              <div className="flex flex-col items-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#b88e4b] mb-4"></div>
                <p className="text-gray-600">Offertevoorstel wordt gegenereerd door onze slimme assistent...</p>
              </div>
            ) : (
              <div className="bg-gray-50 p-8 rounded-2xl border border-gray-100 mb-8 max-w-2xl mx-auto">
                <p className="text-gray-700 text-lg leading-relaxed">
                  {aiSummary}
                </p>
              </div>
            )}
            <button 
              onClick={() => window.location.href = '/'}
              className="bg-[#b88e4b] text-white px-8 py-3 rounded-lg font-bold hover:bg-[#a07a3d] transition-all"
            >
              Terug naar Home
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Interactieve Offerte Tool</h1>
          <p className="text-gray-600">Ontvang een snelle indicatie voor uw bouwproject in slechts enkele stappen.</p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
          {/* Progress Bar */}
          {step < 5 && (
            <div className="bg-gray-100 h-2 w-full">
              <div 
                className="bg-[#b88e4b] h-full transition-all duration-500 ease-out" 
                style={{ width: `${(step / 4) * 100}%` }}
              ></div>
            </div>
          )}

          <div className="p-8 md:p-12">
            {renderStep()}

            {step < 5 && (
              <div className="flex justify-between items-center mt-12 pt-8 border-t border-gray-100">
                <button 
                  onClick={prevStep}
                  disabled={step === 1}
                  className={`flex items-center gap-2 font-bold ${step === 1 ? 'text-gray-300' : 'text-gray-500 hover:text-gray-800 transition-colors'}`}
                >
                  <i className="fas fa-arrow-left"></i> Vorige
                </button>
                
                <button 
                  onClick={nextStep}
                  disabled={step === 1 && !formData.projectType}
                  className={`bg-[#b88e4b] text-white px-10 py-4 rounded-xl font-bold hover:bg-[#a07a3d] transition-all flex items-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {step === 4 ? 'Verstuur Aanvraag' : 'Volgende Stap'}
                  <i className="fas fa-arrow-right"></i>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Benefits Sidebar (Mobile bottom) */}
        {step < 5 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <div className="flex items-center gap-4 bg-white p-6 rounded-2xl shadow-sm">
              <div className="text-[#b88e4b] text-2xl"><i className="fas fa-bolt"></i></div>
              <p className="text-sm font-semibold text-gray-700">Snelle indicatie binnen 2 minuten</p>
            </div>
            <div className="flex items-center gap-4 bg-white p-6 rounded-2xl shadow-sm">
              <div className="text-[#b88e4b] text-2xl"><i className="fas fa-calculator"></i></div>
              <p className="text-sm font-semibold text-gray-700">Berekening op basis van maatwerk</p>
            </div>
            <div className="flex items-center gap-4 bg-white p-6 rounded-2xl shadow-sm">
              <div className="text-[#b88e4b] text-2xl"><i className="fas fa-user-check"></i></div>
              <p className="text-sm font-semibold text-gray-700">Persoonlijke opvolging gegarandeerd</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuoteTool;
