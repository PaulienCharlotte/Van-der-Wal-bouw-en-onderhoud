
import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://picsum.photos/id/122/1920/1080" 
            alt="Vakwerk Bouw" 
            className="w-full h-full object-cover brightness-[0.4]"
          />
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Bouwen met <span className="text-[#b88e4b]">Precisie</span> en Passie.
            </h1>
            <p className="text-xl text-gray-200 mb-10 leading-relaxed">
              Van renovaties tot maatwerk meubilair. Als meester-timmerman en zelfstandig ondernemer breng ik uw woonwensen tot leven met oog voor elk detail.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/offerte" className="bg-[#b88e4b] text-white px-8 py-4 rounded-md font-bold text-lg hover:bg-[#a07a3d] transition-all text-center">
                Vraag een Offerte aan
              </Link>
              <Link to="/diensten" className="bg-white/10 backdrop-blur-md text-white border border-white/30 px-8 py-4 rounded-md font-bold text-lg hover:bg-white/20 transition-all text-center">
                Onze Diensten
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-12 bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center md:justify-between items-center gap-8 opacity-60">
            <div className="flex items-center gap-3">
              <i className="fas fa-check-circle text-[#b88e4b] text-2xl"></i>
              <span className="font-bold uppercase tracking-wider">15+ Jaar Ervaring</span>
            </div>
            <div className="flex items-center gap-3">
              <i className="fas fa-certificate text-[#b88e4b] text-2xl"></i>
              <span className="font-bold uppercase tracking-wider">Gecertificeerd Vakmanschap</span>
            </div>
            <div className="flex items-center gap-3">
              <i className="fas fa-shield-alt text-[#b88e4b] text-2xl"></i>
              <span className="font-bold uppercase tracking-wider">Volledige Garantie</span>
            </div>
            <div className="flex items-center gap-3">
              <i className="fas fa-users text-[#b88e4b] text-2xl"></i>
              <span className="font-bold uppercase tracking-wider">Persoonlijk Contact</span>
            </div>
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img 
                src="https://picsum.photos/id/101/800/1000" 
                alt="Johan de Bouwer" 
                className="rounded-lg shadow-2xl relative z-10"
              />
              <div className="absolute -bottom-8 -right-8 w-64 h-64 border-8 border-[#b88e4b]/20 -z-0"></div>
            </div>
            <div>
              <span className="text-[#b88e4b] font-bold uppercase tracking-widest text-sm mb-4 block">Maak Kennis</span>
              <h2 className="text-4xl font-bold mb-6 text-gray-900">Eén man, eindeloze mogelijkheden</h2>
              <p className="text-gray-600 mb-6 text-lg leading-relaxed">
                Mijn naam is Johan, en ik geloof dat kwaliteit geen concessies kent. Als eenmanszaak ben ik uw enige aanspreekpunt: van het eerste ontwerp tot de laatste schroef.
              </p>
              <p className="text-gray-600 mb-8 text-lg leading-relaxed">
                Geen grote bouwploegen over de vloer, maar één vakman die uw project de aandacht geeft die het verdient. Mijn focus ligt op duurzame materialen en tijdloze resultaten.
              </p>
              <Link to="/over-ons" className="inline-flex items-center gap-2 text-[#b88e4b] font-bold hover:gap-4 transition-all">
                Lees meer over mijn werkwijze <i className="fas fa-arrow-right"></i>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Projects/Stats */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-16">
          <h2 className="text-4xl font-bold mb-4">Onze Specialisaties</h2>
          <div className="w-20 h-1 bg-[#b88e4b] mx-auto"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="bg-white p-10 rounded-xl shadow-sm border border-gray-100 hover:shadow-xl transition-all group">
            <div className="w-16 h-16 bg-[#b88e4b]/10 text-[#b88e4b] flex items-center justify-center rounded-lg mb-8 group-hover:bg-[#b88e4b] group-hover:text-white transition-colors">
              <i className="fas fa-home text-2xl"></i>
            </div>
            <h3 className="text-2xl font-bold mb-4">Renovatie</h3>
            <p className="text-gray-600">Modernisering van bestaande woningen met behoud van karakter en verbetering van comfort.</p>
          </div>
          
          <div className="bg-white p-10 rounded-xl shadow-sm border border-gray-100 hover:shadow-xl transition-all group">
            <div className="w-16 h-16 bg-[#b88e4b]/10 text-[#b88e4b] flex items-center justify-center rounded-lg mb-8 group-hover:bg-[#b88e4b] group-hover:text-white transition-colors">
              <i className="fas fa-tools text-2xl"></i>
            </div>
            <h3 className="text-2xl font-bold mb-4">Maatwerk</h3>
            <p className="text-gray-600">Unieke kasten, trappen en meubilair precies passend in uw interieur en stijl.</p>
          </div>
          
          <div className="bg-white p-10 rounded-xl shadow-sm border border-gray-100 hover:shadow-xl transition-all group">
            <div className="w-16 h-16 bg-[#b88e4b]/10 text-[#b88e4b] flex items-center justify-center rounded-lg mb-8 group-hover:bg-[#b88e4b] group-hover:text-white transition-colors">
              <i className="fas fa-hard-hat text-2xl"></i>
            </div>
            <h3 className="text-2xl font-bold mb-4">Aanbouw</h3>
            <p className="text-2xl font-bold mb-4 tracking-tight">Structuur & Uitbouw</p>
            <p className="text-gray-600">Creëer de extra ruimte die u nodig heeft met een vakkundige uitbreiding van uw woonoppervlak.</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-[#b88e4b]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Klaar om uw project te starten?</h2>
            <p className="text-white/80 text-lg">Gebruik onze interactieve tool voor een directe kostenindicatie.</p>
          </div>
          <Link to="/offerte" className="bg-white text-[#b88e4b] px-10 py-4 rounded-md font-bold text-xl hover:bg-gray-100 transition-all whitespace-nowrap">
            Bereken uw Offerte
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
